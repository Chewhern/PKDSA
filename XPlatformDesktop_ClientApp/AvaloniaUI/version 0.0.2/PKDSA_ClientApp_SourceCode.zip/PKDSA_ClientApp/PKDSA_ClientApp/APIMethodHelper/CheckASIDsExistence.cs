﻿using PKDSA_ClientApp.Helper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace PKDSA_ClientApp.APIMethodHelper
{
    public static class CheckASIDsExistence
    {
        private static String AccountSupportRootFolder = "";
        private static String OldAccountSupportRootFolder = "";
        private static String[] AS_IDs = new String[] { };
        private static String[] AS_IDS_With_Extension = new String[] { };
        private static Boolean[] AS_IDs_Status = new Boolean[] { };

        private static void GetASIDs() 
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true) 
            {
                AccountSupportRootFolder = AppContext.BaseDirectory + "\\AccountSupport\\";
                OldAccountSupportRootFolder = AppContext.BaseDirectory + "\\OldAccountSupport\\";
            }
            else 
            {
                AccountSupportRootFolder = AppContext.BaseDirectory + "/AccountSupport/";
                OldAccountSupportRootFolder = AppContext.BaseDirectory + "/OldAccountSupport/";
            }
            if (Directory.Exists(OldAccountSupportRootFolder) == false)
            {
                Directory.CreateDirectory(OldAccountSupportRootFolder);
            }
            DirectoryInfo myDirectoryInfo = new DirectoryInfo(AccountSupportRootFolder);
            FileInfo[] Files = myDirectoryInfo.GetFiles();
            int Loop = 0;
            AS_IDs = new String[Files.Length];
            AS_IDS_With_Extension = new String[Files.Length];
            while (Loop < Files.Length) 
            {
                AS_IDS_With_Extension[Loop] = Files[Loop].Name;
                AS_IDs[Loop] = AS_IDS_With_Extension[Loop].Substring(0, AS_IDS_With_Extension[Loop].Length - 4);
                Loop += 1;
            }
            AS_IDs_Status = new Boolean[Files.Length];
        }

        public async static void LocalMoveAccountSupportTickets() 
        {
            GetASIDs();
            AS_IDs_Status = await CheckStatusOfAccountSupportTickets();
            int Loop = 0;
            while (Loop < AS_IDs.Length) 
            {
                if (AS_IDs_Status[Loop] == true) 
                {
                    File.Move(AccountSupportRootFolder + AS_IDS_With_Extension[Loop], OldAccountSupportRootFolder + AS_IDS_With_Extension[Loop]);
                }
                Loop += 1;
            }
        }

        private static async Task<Boolean[]> CheckStatusOfAccountSupportTickets() 
        {
            int Loop = 0;
            Boolean[] Status = new Boolean[AS_IDs.Length];
            while(Loop<AS_IDs.Length) 
            {
                if (TORMainOperations.UsingTor == true)
                {
                    var handler = new HttpClientHandler
                    {
                        Proxy = new WebProxy(new Uri("socks5://localhost:19050"))
                    };

                    using (handler)
                    using (var client = new HttpClient(handler))
                    {
                        client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = await client.GetAsync("AccountSupport/CheckSupportTicketStatus?AS_ID=" + AS_IDs[Loop]);
                        if (response.IsSuccessStatusCode)
                        {
                            var readTask = response.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;

                            if (int.Parse(Result.Substring(1, Result.Length - 2)) == 1)
                            {
                                Status[Loop] = true;
                            }
                            else
                            {
                                Status[Loop] = false;
                            }
                        }
                        else
                        {
                            Status[Loop] = false;
                        }
                    }
                }
                else
                {
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = client.GetAsync("AccountSupport/CheckSupportTicketStatus?AS_ID=" + AS_IDs[Loop]);
                        response.Wait();
                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;

                            if (int.Parse(Result.Substring(1, Result.Length - 2))==1)
                            {
                                Status[Loop] = true;
                            }
                            else 
                            {
                                Status[Loop] = false;
                            }
                        }
                        else
                        {
                            Status[Loop] = false;
                        }
                    }
                }
                Loop += 1;
            }
            return Status;
        }
    }
}

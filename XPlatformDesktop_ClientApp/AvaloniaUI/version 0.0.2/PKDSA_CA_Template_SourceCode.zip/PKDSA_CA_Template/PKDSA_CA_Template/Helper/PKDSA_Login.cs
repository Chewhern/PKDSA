﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using ASodium;
using BCASodium;
using PKDSA_CA_Template.Model;
using PKDSA_CA_Template.APIMethodHelper;
using System.Net.Http.Headers;
using System.Net.Http;

namespace PKDSA_CA_Template.Helper
{
    public static class PKDSA_Login
    {
        private static String AppRootFolder = "";

        public static async Task <Boolean> Login() 
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                AppRootFolder = AppContext.BaseDirectory + "\\PKDSA_Credentials\\";
            }
            else
            {
                AppRootFolder = AppContext.BaseDirectory + "/PKDSA_Credentials/";
            }
            if(File.Exists(AppRootFolder+"User_ID.txt")==false || File.Exists(AppRootFolder+"KeyIdentifier.txt")==false ||
                File.Exists(AppRootFolder + "Private_Key.txt") == false) 
            {
                return false;
            }
            else 
            {
                String UserID = File.ReadAllText(AppRootFolder + "User_ID.txt");
                String KeyIdentifier = File.ReadAllText(AppRootFolder + "KeyIdentifier.txt");
                Byte[] SignedChallengeFromServer = new Byte[] { };
                Byte[] ChallengeFromServer = new Byte[] { };
                Byte[] ServerPublicKey = new Byte[] { };
                Byte[] UserSignedChallenge = new Byte[] { };
                LoginModels myLoginModel = await ChallengeRequestor.RequestChallengeFromServer(UserID, KeyIdentifier);
                Byte[] PrivateKey = File.ReadAllBytes(AppRootFolder + "Private_Key.txt");
                if (myLoginModel.RequestStatus.Contains("Error") == true)
                {
                    return false;
                }
                else
                {
                    ServerPublicKey = Convert.FromBase64String(myLoginModel.ServerECDSAPKBase64String);
                    SignedChallengeFromServer = Convert.FromBase64String(myLoginModel.SignedRandomChallengeBase64String);
                    ChallengeFromServer = SodiumPublicKeyAuth.Verify(SignedChallengeFromServer, ServerPublicKey);
                    if (PrivateKey.Length == 56) 
                    {
                        UserSignedChallenge = SecureED448.GenerateSignatureMessage(PrivateKey, ChallengeFromServer, new Byte[] { }, true);
                    }
                    else 
                    {
                        UserSignedChallenge = SodiumPublicKeyAuth.Sign(ChallengeFromServer, PrivateKey, true);
                    }
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri("<API IP Address>");
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = client.GetAsync("UserLogin?User_ID=" + UserID + "&Key_Identifier=" + KeyIdentifier + "&URLEncoded_Signed_Challenge=" + System.Web.HttpUtility.UrlEncode(Convert.ToBase64String(UserSignedChallenge)));
                        response.Wait();
                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;

                            String Status = Result.Substring(1, Result.Length - 2);
                            Console.WriteLine(Status);
                            if (Status.Contains("Error") == false) 
                            {
                                return true;
                            }
                            else 
                            {
                                return false;
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
        }
    }
}

﻿namespace PKDSA_CA_Template.ViewModels;

public partial class MainViewModel : ViewModelBase
{

}

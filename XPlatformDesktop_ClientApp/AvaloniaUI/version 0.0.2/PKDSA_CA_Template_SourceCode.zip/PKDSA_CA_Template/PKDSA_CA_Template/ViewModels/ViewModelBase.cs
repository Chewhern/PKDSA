﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace PKDSA_CA_Template.ViewModels;

public class ViewModelBase : ObservableObject
{
}

﻿using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using ASodium;
using BCASodium;
using System;
using System.IO;
using System.Runtime.InteropServices;
using Avalonia.Media;
using PKDSA_CA_Template.Helper;

namespace PKDSA_CA_Template.Views;

public partial class MainView : UserControl
{
    private static int SigningAppUIChooser;
    private static TextBlock[] FirstSAppmyTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstSAppmyTBArray = new TextBox[] { };
    private static Button[] FirstSAppmyButtonArray = new Button[] { };
    private static String AppRootFolder = "";
    private static Boolean HasUIRendered = false;

    public MainView()
    {
        InitializeComponent();
        SAppInitialization();
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
        {
            AppRootFolder = AppContext.BaseDirectory + "\\PKDSA_Credentials\\";
        }
        else
        {
            AppRootFolder = AppContext.BaseDirectory + "/PKDSA_Credentials/";
        }
        if (Directory.Exists(AppRootFolder) == false)
        {
            Directory.CreateDirectory(AppRootFolder);
        }
        EnableTemplateInterface();
    }

    private void SAppInitialization()
    {
        SigningAppUIChooser = 0;
        CA_Template_AppToggleBTN1.IsCheckedChanged += SigningAppToggleBTNSFunction;
        CA_Template_AppSBTN1.Click += ManualLoginButton;
    }

    private async void ManualLoginButton(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        //Do something
        //Can change accordingly by referring to your own usage
        EnableTemplateInterface();
    }

    private void SigningAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if (CA_Template_AppToggleBTN1.IsChecked == true)
        {
            SigningAppUIChooser = 1;
        }
        else
        {
            ResetSigningAppUI();
        }
        SigningAppDrawUI();
    }

    private void SigningAppDrawUI()
    {
        if (SigningAppUIChooser == 1)
        {
            if (HasUIRendered == false)
            {
                FirstSAppmyTextBlockArray = new TextBlock[4];
                FirstSAppmyTextBlockArray[0] = new TextBlock();
                FirstSAppmyTextBlockArray[1] = new TextBlock();
                FirstSAppmyTextBlockArray[2] = new TextBlock();
                FirstSAppmyTextBlockArray[3] = new TextBlock();
                FirstSAppmyTextBlockArray[0].Text = "Sample Label (1)";
                FirstSAppmyTextBlockArray[1].Text = "Sample Label (2)";
                FirstSAppmyTextBlockArray[2].Text = "Sample Label (3)";
                FirstSAppmyTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstSAppmyTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstSAppmyTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstSAppmyTextBlockArray[3].Text = "In order to use the template, the minimum requirement is to copy" +
                    Environment.NewLine + "UserID, SubKeyIdentifier(Reside within SAppDSKP), chosen SKI's key pair"+
                    Environment.NewLine + "from PKDSA_ClientApp and paste them within 'PKDSA_Credentials' folder."+
                    Environment.NewLine + "The format must be User_ID.txt, KeyIdentifier.txt, and Private_Key.txt"+
                    Environment.NewLine + "The rest should be handled by the provider if they chose to use this"+
                    Environment.NewLine + "template.";
                FirstSAppmyTBArray = new TextBox[3];
                FirstSAppmyTBArray[0] = new TextBox();
                FirstSAppmyTBArray[1] = new TextBox();
                FirstSAppmyTBArray[2] = new TextBox();
                FirstSAppmyTBArray[0].AcceptsReturn = true;
                FirstSAppmyTBArray[1].AcceptsReturn = true;
                FirstSAppmyTBArray[2].AcceptsReturn = true;
                FirstSAppmyTBArray[0].TextWrapping = TextWrapping.Wrap;
                FirstSAppmyTBArray[1].TextWrapping = TextWrapping.Wrap;
                FirstSAppmyTBArray[2].TextWrapping = TextWrapping.Wrap;
                FirstSAppmyButtonArray = new Button[1];
                FirstSAppmyButtonArray[0] = new Button();
                FirstSAppmyButtonArray[0].Margin = Avalonia.Thickness.Parse("0,10,0,0");
                FirstSAppmyButtonArray[0].Content = "Sample Button";
                FirstSAppmyButtonArray[0].Click += SigningAppBTN_Click;
                CA_Template_AppLowerRightSP.Children.Add(FirstSAppmyTextBlockArray[0]);
                CA_Template_AppLowerRightSP.Children.Add(FirstSAppmyTBArray[0]);
                CA_Template_AppLowerRightSP.Children.Add(FirstSAppmyTextBlockArray[1]);
                CA_Template_AppLowerRightSP.Children.Add(FirstSAppmyTBArray[1]);
                CA_Template_AppLowerRightSP.Children.Add(FirstSAppmyTextBlockArray[2]);
                CA_Template_AppLowerRightSP.Children.Add(FirstSAppmyTBArray[2]);
                CA_Template_AppLowerRightSP.Children.Add(FirstSAppmyButtonArray[0]);
                CA_Template_AppLowerRightSP.Children.Add(FirstSAppmyTextBlockArray[3]);
                HasUIRendered = true;
            }
        }
        else
        {
            ResetSigningAppUI();
        }
    }

    private void ResetSigningAppUI()
    {
        CA_Template_AppToggleBTN1.IsChecked = false;
        SigningAppUIChooser = 0;
        CA_Template_AppLowerRightSP.Children.Clear();
        FirstSAppmyTextBlockArray = new TextBlock[] { };
        FirstSAppmyTBArray = new TextBox[] { };
        FirstSAppmyButtonArray = new Button[] { };
        HasUIRendered = false;
    }

    //Ordinary Winforms or android studio, both have drag and drop with automatic
    //code generation and interface that's aligned
    //AvaloniaUI in a sense, feels like you have to do things from scratch or from an IAAS
    //perspective.. One can find a similar experience when dealing with ordinary
    //PHP and HTML. 
    private void SigningAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        //Do something
    }

    private async void EnableTemplateInterface() 
    {
        Boolean AbleToLogin = await PKDSA_Login.Login();
        if (AbleToLogin)
        {
            CA_Template_AppToggleBTN1.IsEnabled = true;
        }
    }
}

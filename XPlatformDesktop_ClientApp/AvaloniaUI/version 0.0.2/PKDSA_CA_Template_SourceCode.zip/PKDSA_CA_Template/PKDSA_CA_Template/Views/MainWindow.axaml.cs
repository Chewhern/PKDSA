﻿using Avalonia.Controls;

namespace PKDSA_CA_Template.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}

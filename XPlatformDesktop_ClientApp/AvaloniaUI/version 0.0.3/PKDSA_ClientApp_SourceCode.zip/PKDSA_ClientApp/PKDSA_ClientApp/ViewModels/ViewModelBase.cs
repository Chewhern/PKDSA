﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace PKDSA_ClientApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}

﻿namespace PKDSA_ClientApp.ViewModels;

public partial class MainViewModel : ViewModelBase
{
    
}

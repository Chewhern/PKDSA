﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PKDSA_CA_Template.Model;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net;
using System.Net.Http;

namespace PKDSA_CA_Template.APIMethodHelper
{
    public static class ChallengeRequestor
    {
        public static String RequestCStatus = "";

        public static async Task<LoginModels> RequestChallengeFromServer(String User_ID, String Key_Identifier)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://zeroaccesssecuritysolutions.com:5001/api/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await client.GetAsync("ChallengeRequestor?User_ID=" + User_ID + "&Key_Identifier=" + Key_Identifier);
                if (response.IsSuccessStatusCode)
                {
                    var readTask = response.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    return JsonConvert.DeserializeObject<LoginModels>(Result);
                }
                else
                {
                    RequestCStatus = "There's something wrong on the server side..";
                    return new LoginModels();
                }
            }         
        }
    }
}

﻿namespace PKDSA_ServerApp.Model
{
    public class DataModels
    {
        public String[] Data { get; set; }
    }
}

using Microsoft.AspNetCore.DataProtection;
using System.Security.Cryptography.X509Certificates;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.
    AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo("<Path to data protection directory>")).ProtectKeysWithCertificate(
            new X509Certificate2("<Path to PFX certificate>", "PFX certificate's password"));

builder.Services.AddControllers();

builder.WebHost.ConfigureKestrel(serverOptions =>
{
    serverOptions.Listen(System.Net.IPAddress.Parse("0.0.0.0"), 5001, listenOptions =>
    {
        listenOptions.UseHttps("<Path to PFX certificate>", "PFX certificate's password");
    }
    );
}
);

var app = builder.Build();

// Configure the HTTP request pipeline.

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
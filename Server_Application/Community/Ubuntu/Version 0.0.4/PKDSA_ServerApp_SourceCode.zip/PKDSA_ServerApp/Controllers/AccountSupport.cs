﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using PKDSA_ServerApp.Helper;
using PKDSA_ServerApp.Model;

namespace PKDSA_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountSupport : ControllerBase
    {
        private MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public String InitiateSupport(String UserID, int SupportType) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            int Count = 0;
            String ExceptionString = "";
            String AS_ID = CryptographicSecureIDGenerator.GenerateUniqueString();
            if (AS_ID.Length > 32) 
            {
                AS_ID = AS_ID.Substring(0, 32);
            }
            if (!(SupportType == 1 || SupportType == 2)) 
            {
                return "Error: There are two features supported which are changing out of band key and changing the master key";
            }
            else 
            {
                myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `User` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = UserID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 1) 
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Account_Support` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = UserID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    if (Count < 8) 
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "INSERT INTO `Account_Support`(`Support_Type`, `User_ID`,`AS_ID`, `Status`) VALUES (@Support_Type,@User_ID,@AS_ID,@Status)";
                        MySQLGeneralQuery.Parameters.Add("@Support_Type", MySqlDbType.Text).Value = SupportType.ToString();
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = UserID;
                        MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
                        MySQLGeneralQuery.Parameters.Add("@Status", MySqlDbType.Text).Value = "Initialized";
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                        return AS_ID;
                    }
                    else 
                    {
                        myMyOwnMySQLConnection.MyMySQLConnection.Close();
                        return "Error: There're way too many support request filed";
                    }
                }
                else 
                {
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    return "Error: This specified user ID does not exist";
                }
            }
        }

        [HttpGet("InitiateChangeOOBPKProcess")]
        public String ChangeOOBPublicKeyInitiation(String UserID, String AS_ID,String URL_EncodedSignedChallenge, String URL_EncodedUserOOBPublicKey) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            int Count = 0;
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Account_Support` WHERE `User_ID`=@User_ID AND `AS_ID`=@AS_ID AND `Support_Type`=@Support_Type";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = UserID;
            MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
            MySQLGeneralQuery.Parameters.Add("Support_Type", MySqlDbType.Text).Value = "1";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count!=1)
            {
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                return "Error: No such account support request";
            }
            else
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `OOB_PK` FROM `User` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = UserID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                if (MySQLGeneralQuery.ExecuteScalar().ToString().CompareTo("") == 0) 
                {
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    return "Error: This account can't initialize this request";
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "INSERT INTO `AS_Details`(`AS_ID`, `Signed_Challenge`, `OOBPublicKey`) VALUES (@AS_ID,@Signed_Challenge,@OOBPublicKey)";
                MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
                MySQLGeneralQuery.Parameters.Add("@Signed_Challenge", MySqlDbType.Text).Value = URL_EncodedSignedChallenge;
                MySQLGeneralQuery.Parameters.Add("@OOBPublicKey", MySqlDbType.Text).Value = URL_EncodedUserOOBPublicKey;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                return "Success: Temporary details for changing OOB public key have been recorded";
            }
        }

        [HttpGet("InitiateChangeMasterPKProcess")]
        public String ChangeMasterPublicKeyInitiation(String UserID, String AS_ID , String URL_EncodedSignedChallenge, String URLEncoded_Master_Signed_PK, String URLEncoded_Master_PK) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            int Count = 0;
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Account_Support` WHERE `User_ID`=@User_ID AND `AS_ID`=@AS_ID AND `Support_Type`=@Support_Type";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = UserID;
            MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
            MySQLGeneralQuery.Parameters.Add("@Support_Type", MySqlDbType.Text).Value = "2";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count != 1)
            {
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                return "Error: No such account support request";
            }
            else
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `OOB_PK` FROM `User` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = UserID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                if (MySQLGeneralQuery.ExecuteScalar().ToString().CompareTo("") == 0)
                {
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    return "Error: This account can't initialize this request";
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "INSERT INTO `AS_Details`(`AS_ID`, `Signed_Challenge`, `Master_PK`,`Master_Signed_PK`) VALUES (@AS_ID,@Signed_Challenge,@Master_PK,@Master_Signed_PK)";
                MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
                MySQLGeneralQuery.Parameters.Add("@Signed_Challenge", MySqlDbType.Text).Value = URL_EncodedSignedChallenge;
                MySQLGeneralQuery.Parameters.Add("@Master_PK", MySqlDbType.Text).Value = URLEncoded_Master_PK;
                MySQLGeneralQuery.Parameters.Add("@Master_Signed_PK", MySqlDbType.Text).Value = URLEncoded_Master_Signed_PK;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                return "Success: Temporary details for changing master public key have been recorded";
            }
        }

        [HttpGet("CheckSupportTicketStatus")]
        public String CheckAS_IDStatus(String AS_ID) 
        {
            RevampedKeyPair ServerED25519KeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
            Byte[] RandomData = new Byte[] { };
            Byte[] SignedRandomData = new Byte[] { };
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Account_Support` WHERE `AS_ID`=@AS_ID AND `Status`=@Status";
            MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
            MySQLGeneralQuery.Parameters.Add("@Status", MySqlDbType.Text).Value = "Finished";
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            return MySQLGeneralQuery.ExecuteScalar().ToString();
        }
    }
}

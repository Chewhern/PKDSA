﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using PKDSA_AS_ServerApp.Helper;
using PKDSA_AS_ServerApp.Model;

namespace PKDSA_AS_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountSupport : ControllerBase
    {
        private MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet("GetOOBData")]
        public DataModels GetTemporaryOOBDataList(String Admin_ID,String URL_EncodedSignedChallenge) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            int Count = 0;
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Admin` WHERE `Admin_ID`=@Admin_ID";
            MySQLGeneralQuery.Parameters.Add("@Admin_ID", MySqlDbType.Text).Value = Admin_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count != 1)
            {
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                String[] Data = new string[1];
                Data[0] = "Error: This admin does not exist";
                DataModels myDM = new DataModels();
                myDM.Data = Data;
                return myDM;
            }
            else
            {
                String Admin_Master_PublicKeyB64 = "";
                Byte[] Admin_Master_PublicKey = new Byte[] { };
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Master_PK` FROM `Admin` WHERE `Admin_ID`=@Admin_ID";
                MySQLGeneralQuery.Parameters.Add("@Admin_ID", MySqlDbType.Text).Value = Admin_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Admin_Master_PublicKeyB64 = MySQLGeneralQuery.ExecuteScalar().ToString();
                Admin_Master_PublicKey = Convert.FromBase64String(Admin_Master_PublicKeyB64);
                Byte[] Signed_Challenge = Convert.FromBase64String(URL_EncodedSignedChallenge);
                Byte[] Challenge = new Byte[] { };
                if (Admin_Master_PublicKey.Length != 32) 
                {
                    Challenge = SecureED448.GetMessageFromSignatureMessage(Admin_Master_PublicKey, Signed_Challenge, new Byte[] { });
                }
                else 
                {
                    Challenge = SodiumPublicKeyAuth.Verify(Signed_Challenge, Admin_Master_PublicKey);
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Admin_Challenge` WHERE `Challenge`=@Challenge";
                MySQLGeneralQuery.Parameters.Add("@Challenge",MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 1) 
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Account_Support` WHERE `Status`=@Status AND `Support_Type`=@Support_Type";
                    MySQLGeneralQuery.Parameters.Add("@Status", MySqlDbType.Text).Value = "Initialized";
                    MySQLGeneralQuery.Parameters.Add("@Support_Type", MySqlDbType.Text).Value = "1";
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `AS_ID`,`User_ID` FROM `Account_Support` WHERE `Status`= @Status AND `Support_Type`=@Support_Type";
                    MySQLGeneralQuery.Parameters.Add("@Status", MySqlDbType.Text).Value = "Initialized";
                    MySQLGeneralQuery.Parameters.Add("@Support_Type", MySqlDbType.Text).Value = "1";
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();                    
                    String[] AS_IDs = new String[Count];
                    String[] User_IDs = new String[Count];
                    int Loop = 0;
                    MySqlDataReader reader = MySQLGeneralQuery.ExecuteReader();
                    while (reader.Read()) 
                    {
                        AS_IDs[Loop] = reader.GetString("AS_ID");
                        User_IDs[Loop] = reader.GetString("User_ID");
                        Loop++;
                    }
                    String[] PublicKey = new String[Count];
                    String[] SignedChallenge = new String[Count];
                    Loop = 0;
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    while (Loop < Count)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Signed_Challenge` FROM `AS_Details` WHERE `AS_ID`= @AS_ID";
                        MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_IDs[Loop];
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        SignedChallenge[Loop] = MySQLGeneralQuery.ExecuteScalar().ToString();
                        Loop += 1;
                    }
                    Loop = 0;
                    while (Loop < Count)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `OOBPublicKey` FROM `AS_Details` WHERE `AS_ID`= @AS_ID";
                        MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_IDs[Loop];
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        PublicKey[Loop] = MySQLGeneralQuery.ExecuteScalar().ToString();
                        Loop += 1;
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "DELETE FROM `Admin_Challenge` WHERE `Challenge`=@Challenge";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    String[] ActualData = AS_IDs.Concat(User_IDs).Concat(PublicKey).Concat(SignedChallenge).ToArray();
                    DataModels myDM = new DataModels();
                    myDM.Data = ActualData;
                    return myDM;
                }
                else 
                {
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    String[] Data = new string[1];
                    Data[0] = "Error: This verified challenge does not exist";
                    DataModels myDM = new DataModels();
                    myDM.Data = Data;
                    return myDM;
                }
            }
        }

        [HttpGet("ChangeOOB")]
        public String ChangeOOBPublicKey(String AS_ID, String Admin_ID, String URL_EncodedSignedChallenge) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            int Count = 0;
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT `Support_Type` FROM `Account_Support` WHERE `AS_ID`=@AS_ID";
            MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            if (int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString()) != 1) 
            {
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                return "Error: This AS_ID is under different category";
            }
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Admin` WHERE `Admin_ID`=@Admin_ID";
            MySQLGeneralQuery.Parameters.Add("@Admin_ID", MySqlDbType.Text).Value = Admin_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count != 1)
            {
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                return "Error: This admin does not exist";
            }
            else
            {
                String Admin_Master_PublicKeyB64 = "";
                Byte[] Admin_Master_PublicKey = new Byte[] { };
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Master_PK` FROM `Admin` WHERE `Admin_ID`=@Admin_ID";
                MySQLGeneralQuery.Parameters.Add("@Admin_ID", MySqlDbType.Text).Value = Admin_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Admin_Master_PublicKeyB64 = MySQLGeneralQuery.ExecuteScalar().ToString();
                Admin_Master_PublicKey = Convert.FromBase64String(Admin_Master_PublicKeyB64);
                Byte[] Signed_Challenge = Convert.FromBase64String(URL_EncodedSignedChallenge);
                Byte[] Challenge = new Byte[] { };
                if (Admin_Master_PublicKey.Length != 32)
                {
                    Challenge = SecureED448.GetMessageFromSignatureMessage(Admin_Master_PublicKey, Signed_Challenge, new Byte[] { });
                }
                else
                {
                    Challenge = SodiumPublicKeyAuth.Verify(Signed_Challenge, Admin_Master_PublicKey);
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Admin_Challenge` WHERE `Challenge`=@Challenge";
                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 1)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "UPDATE `AS_Details` SET `OOBPublicKey`=@OOBPublicKey,`Signed_Challenge`=@Signed_Challenge WHERE `AS_ID`=@AS_ID";
                    MySQLGeneralQuery.Parameters.Add("@OOBPublicKey", MySqlDbType.Text).Value = "";
                    MySQLGeneralQuery.Parameters.Add("@Signed_Challenge", MySqlDbType.Text).Value = "";
                    MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "UPDATE `Account_Support` SET `Status`=@Status WHERE `AS_ID`=@AS_ID";
                    MySQLGeneralQuery.Parameters.Add("@Status", MySqlDbType.Text).Value = "Finished";
                    MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "DELETE FROM `Admin_Challenge` WHERE `Challenge`=@Challenge";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    return "Success: The out of band public key of user have been updated";
                }
                else
                {
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    return "Error: This verified challenge does not exist";
                }
            }
        }

        [HttpGet("GetChangeMPKData")]
        public DataModels GetChangeMasterPKRequests(String Admin_ID, String URL_EncodedSignedChallenge)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            int Count = 0;
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Admin` WHERE `Admin_ID`=@Admin_ID";
            MySQLGeneralQuery.Parameters.Add("@Admin_ID", MySqlDbType.Text).Value = Admin_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count != 1)
            {
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                String[] Data = new string[1];
                Data[0] = "Error: This admin does not exist";
                DataModels myDM = new DataModels();
                myDM.Data = Data;
                return myDM;
            }
            else
            {
                String Admin_Master_PublicKeyB64 = "";
                Byte[] Admin_Master_PublicKey = new Byte[] { };
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Master_PK` FROM `Admin` WHERE `Admin_ID`=@Admin_ID";
                MySQLGeneralQuery.Parameters.Add("@Admin_ID", MySqlDbType.Text).Value = Admin_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Admin_Master_PublicKeyB64 = MySQLGeneralQuery.ExecuteScalar().ToString();
                Admin_Master_PublicKey = Convert.FromBase64String(Admin_Master_PublicKeyB64);
                Byte[] Signed_Challenge = Convert.FromBase64String(URL_EncodedSignedChallenge);
                Byte[] Challenge = new Byte[] { };
                if (Admin_Master_PublicKey.Length != 32)
                {
                    Challenge = SecureED448.GetMessageFromSignatureMessage(Admin_Master_PublicKey, Signed_Challenge, new Byte[] { });
                }
                else
                {
                    Challenge = SodiumPublicKeyAuth.Verify(Signed_Challenge, Admin_Master_PublicKey);
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Admin_Challenge` WHERE `Challenge`=@Challenge";
                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 1)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Account_Support` WHERE `Status`=@Status AND `Support_Type`=@Support_Type";
                    MySQLGeneralQuery.Parameters.Add("@Status", MySqlDbType.Text).Value = "Initialized";
                    MySQLGeneralQuery.Parameters.Add("@Support_Type", MySqlDbType.Text).Value = "2";
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `AS_ID`,`User_ID` FROM `Account_Support` WHERE `Status`= @Status AND `Support_Type`=@Support_Type";
                    MySQLGeneralQuery.Parameters.Add("@Status", MySqlDbType.Text).Value = "Initialized";
                    MySQLGeneralQuery.Parameters.Add("@Support_Type", MySqlDbType.Text).Value = "2";
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    String[] AS_IDs = new String[Count];
                    String[] User_IDs = new String[Count];
                    String[] SignedChallenge = new String[Count];
                    int Loop = 0;
                    MySqlDataReader reader = MySQLGeneralQuery.ExecuteReader();
                    while (reader.Read())
                    {
                        AS_IDs[Loop] = reader.GetString("AS_ID");
                        User_IDs[Loop] = reader.GetString("User_ID");
                        Loop++;
                    }
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    Loop = 0;
                    while (Loop < Count)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Signed_Challenge` FROM `AS_Details` WHERE `AS_ID`= @AS_ID";
                        MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_IDs[Loop];
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        SignedChallenge[Loop] = MySQLGeneralQuery.ExecuteScalar().ToString();
                        Loop += 1;
                    }
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "DELETE FROM `Admin_Challenge` WHERE `Challenge`=@Challenge";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    DataModels myDM = new DataModels();
                    myDM.Data = AS_IDs.Concat(User_IDs).Concat(SignedChallenge).ToArray();
                    return myDM;
                }
                else
                {
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    String[] Data = new string[1];
                    Data[0] = "Error: This verified challenge does not exist";
                    DataModels myDM = new DataModels();
                    myDM.Data = Data;
                    return myDM;
                }
            }
        }

        [HttpGet("ChangeMPK")]
        public String ChangeMasterPublicKey(String AS_ID, String Admin_ID, String URL_EncodedSignedChallenge)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            int Count = 0;
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT `Support_Type` FROM `Account_Support` WHERE `AS_ID`=@AS_ID";
            MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            if (int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString()) != 2)
            {
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                return "Error: This AS_ID is under different category";
            }
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Admin` WHERE `Admin_ID`=@Admin_ID";
            MySQLGeneralQuery.Parameters.Add("@Admin_ID", MySqlDbType.Text).Value = Admin_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count != 1)
            {
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                return "Error: This admin does not exist";
            }
            else
            {
                String Admin_Master_PublicKeyB64 = "";
                Byte[] Admin_Master_PublicKey = new Byte[] { };
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Master_PK` FROM `Admin` WHERE `Admin_ID`=@Admin_ID";
                MySQLGeneralQuery.Parameters.Add("@Admin_ID", MySqlDbType.Text).Value = Admin_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Admin_Master_PublicKeyB64 = MySQLGeneralQuery.ExecuteScalar().ToString();
                Admin_Master_PublicKey = Convert.FromBase64String(Admin_Master_PublicKeyB64);
                Byte[] Signed_Challenge = Convert.FromBase64String(URL_EncodedSignedChallenge);
                Byte[] Challenge = new Byte[] { };
                if (Admin_Master_PublicKey.Length != 32)
                {
                    Challenge = SecureED448.GetMessageFromSignatureMessage(Admin_Master_PublicKey, Signed_Challenge, new Byte[] { });
                }
                else
                {
                    Challenge = SodiumPublicKeyAuth.Verify(Signed_Challenge, Admin_Master_PublicKey);
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Admin_Challenge` WHERE `Challenge`=@Challenge";
                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 1)
                {
                    String MasterPublicKey = "";
                    String MasterSignedPublicKey = "";
                    String User_ID = "";
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Master_PK` FROM `AS_Details` WHERE `AS_ID`=@AS_ID";
                    MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MasterPublicKey = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Master_Signed_PK` FROM `AS_Details` WHERE `AS_ID`=@AS_ID";
                    MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MasterSignedPublicKey = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `User_ID` FROM `Account_Support` WHERE `AS_ID`=@AS_ID";
                    MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    User_ID = MySQLGeneralQuery.ExecuteScalar().ToString();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "UPDATE `AS_Details` SET `Master_Signed_PK`=@Master_Signed_PK,`Master_PK`=@Master_PK,`Signed_Challenge`=@Signed_Challenge WHERE `AS_ID`=@AS_ID";
                    MySQLGeneralQuery.Parameters.Add("@Signed_Challenge", MySqlDbType.Text).Value = "";
                    MySQLGeneralQuery.Parameters.Add("@Master_Signed_PK", MySqlDbType.Text).Value = "";
                    MySQLGeneralQuery.Parameters.Add("@Master_PK", MySqlDbType.Text).Value = "";
                    MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "UPDATE `User` SET `Master_Signed_PK`=@Master_Signed_PK,`Master_PK`=@Master_PK WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@Master_Signed_PK", MySqlDbType.Text).Value = MasterSignedPublicKey;
                    MySQLGeneralQuery.Parameters.Add("@Master_PK", MySqlDbType.Text).Value = MasterPublicKey;
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "UPDATE `Account_Support` SET `Status`=@Status WHERE `AS_ID`=@AS_ID";
                    MySQLGeneralQuery.Parameters.Add("@Status", MySqlDbType.Text).Value = "Finished";
                    MySQLGeneralQuery.Parameters.Add("@AS_ID", MySqlDbType.Text).Value = AS_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "DELETE FROM `Admin_Challenge` WHERE `Challenge`=@Challenge";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    return "Success: The out of band public key of user have been updated";
                }
                else
                {
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    return "Error: This verified challenge does not exist";
                }
            }
        }

        [HttpGet("DeleteSupportChallenge")]
        public String DeleteSupportChallenge(String User_Challenge, String Admin_ID, String URL_EncodedSignedChallenge) 
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            int Count = 0;
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Admin` WHERE `Admin_ID`=@Admin_ID";
            MySQLGeneralQuery.Parameters.Add("@Admin_ID", MySqlDbType.Text).Value = Admin_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count != 1)
            {
                myMyOwnMySQLConnection.MyMySQLConnection.Close();
                return "Error: This admin does not exist";
            }
            else
            {
                String Admin_Master_PublicKeyB64 = "";
                Byte[] Admin_Master_PublicKey = new Byte[] { };
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Master_PK` FROM `Admin` WHERE `Admin_ID`=@Admin_ID";
                MySQLGeneralQuery.Parameters.Add("@Admin_ID", MySqlDbType.Text).Value = Admin_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Admin_Master_PublicKeyB64 = MySQLGeneralQuery.ExecuteScalar().ToString();
                Admin_Master_PublicKey = Convert.FromBase64String(Admin_Master_PublicKeyB64);
                Byte[] Signed_Challenge = Convert.FromBase64String(URL_EncodedSignedChallenge);
                Byte[] Challenge = new Byte[] { };
                if (Admin_Master_PublicKey.Length != 32)
                {
                    Challenge = SecureED448.GetMessageFromSignatureMessage(Admin_Master_PublicKey, Signed_Challenge, new Byte[] { });
                }
                else
                {
                    Challenge = SodiumPublicKeyAuth.Verify(Signed_Challenge, Admin_Master_PublicKey);
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Admin_Challenge` WHERE `Challenge`=@Challenge";
                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 1)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "DELETE FROM `Admin_Challenge` WHERE `Challenge`=@Challenge";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Support_Challenge` WHERE `Challenge`=@Challenge";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = User_Challenge;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    String Result = "";
                    if (Count == 1) 
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "DELETE FROM `Support_Challenge` WHERE `Challenge`=@Challenge";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = User_Challenge;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                        Result = "Success: This support challenge has been deleted";
                    }
                    else 
                    {
                        Result = "Error: This support challenge doesn't exist";
                    }
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    return Result;
                }
                else
                {
                    myMyOwnMySQLConnection.MyMySQLConnection.Close();
                    return "Error: This verified challenge does not exist";
                }
            }
        }
    }
}

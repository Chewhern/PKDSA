﻿namespace PKDSA_AS_ServerApp.Model
{
    public class DataModels
    {
        public String[] Data { get; set; }
    }
}

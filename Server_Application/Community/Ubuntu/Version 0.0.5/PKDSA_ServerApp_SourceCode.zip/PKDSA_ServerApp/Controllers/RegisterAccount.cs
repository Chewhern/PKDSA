﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PKDSA_ServerApp.Helper;
using MySql.Data.MySqlClient;

namespace PKDSA_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegisterAccount : ControllerBase
    {
        private MyOwnMySQLConnection MyMyOwnMySQLConnectionClass = new MyOwnMySQLConnection();

        //OOB = Out of band
        //If the OOB pk holder remain unchange, then it could have confidentiality, integrity and availability.
        //This will allow for communication based on key and email/phone number/other applicable
        //communication channel that could bypass censorship to an extent.
        [HttpGet]
        public String CreateAccountWithoutSession(String User_ID, String URLEncoded_OOB_PK, String URLEncoded_Master_Signed_PK, String URLEncoded_Master_PK)
        {
            String Status = "";
            DecodeDataClass decodeDataClass = new DecodeDataClass();
            String DecodedMaster_Signed_PK = "";
            Boolean DecodingMaster_Signed_PK = true;
            String DecodedMaster_PK = "";
            Boolean DecodingMaster_PK = true;
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            int UserIDChecker = 0;
            DateTime UTC8DateTime = DateTime.UtcNow.AddHours(8);
            decodeDataClass.DecodeDataFunction(ref DecodingMaster_Signed_PK, ref DecodedMaster_Signed_PK, URLEncoded_Master_Signed_PK);
            decodeDataClass.DecodeDataFunction(ref DecodingMaster_PK, ref DecodedMaster_PK, URLEncoded_Master_PK);
            if (DecodingMaster_Signed_PK == true && DecodingMaster_PK == true)
            {
                MyMyOwnMySQLConnectionClass.LoadConnection(ref ExceptionString);
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `User` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = MyMyOwnMySQLConnectionClass.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                UserIDChecker = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (UserIDChecker == 0)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MyMyOwnMySQLConnectionClass.MyMySQLConnection.Close();
                    MyMyOwnMySQLConnectionClass.LoadConnection(ref ExceptionString);
                    MySQLGeneralQuery.CommandText = "INSERT INTO `User`(`User_ID`, `OOB_PK` ,`Master_Signed_PK`, `Master_PK`, `Register_Date`) VALUES (@User_ID,@OOB_PK,@Master_Signed_PK,@Master_PK,@Register_Date)";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Parameters.Add("@OOB_PK", MySqlDbType.Text).Value = URLEncoded_OOB_PK;
                    MySQLGeneralQuery.Parameters.Add("@Master_Signed_PK", MySqlDbType.Text).Value = DecodedMaster_Signed_PK;
                    MySQLGeneralQuery.Parameters.Add("@Master_PK", MySqlDbType.Text).Value = DecodedMaster_PK;
                    MySQLGeneralQuery.Parameters.Add("@Register_Date", MySqlDbType.DateTime).Value = UTC8DateTime;
                    MySQLGeneralQuery.Connection = MyMyOwnMySQLConnectionClass.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    Status = "Congratulations: Your account has been registered with OOB key pair (Communication)";
                }
                else
                {
                    Status = "Error: The user ID have already existed ... Use another one instead";
                }
                MyMyOwnMySQLConnectionClass.MyMySQLConnection.Close();
            }
            else
            {
                Status = "Error: You didn't pass in correct URL encoded parameter value...";
            }
            return Status;
        }
    }
}

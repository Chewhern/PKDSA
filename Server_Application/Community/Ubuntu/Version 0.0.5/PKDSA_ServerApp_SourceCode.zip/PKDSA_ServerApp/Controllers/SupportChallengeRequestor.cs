﻿using ASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using PKDSA_ServerApp.Helper;
using PKDSA_ServerApp.Model;

namespace PKDSA_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupportChallengeRequestor : ControllerBase
    {
        private MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public LoginModels RequestChallenge(String User_ID)
        {
            LoginModels MyLoginModels = new LoginModels();
            RevampedKeyPair ServerED25519KeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
            Byte[] RandomData = SodiumRNG.GetRandomBytes(128);
            Byte[] SignedRandomData = new Byte[] { };
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            int Count = 0;
            String ExceptionString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Support_Challenge` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 0) 
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Support_Challenge` WHERE `Challenge`=@Challenge";
                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(RandomData);
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                while (Count != 0)
                {
                    RandomData = SodiumRNG.GetRandomBytes(128);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Support_Challenge` WHERE `Challenge`=@Challenge";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(RandomData);
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "INSERT INTO `Support_Challenge`(`Challenge`, `User_ID`) VALUES (@Challenge,@User_ID)";
                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(RandomData);
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                SignedRandomData = SodiumPublicKeyAuth.Sign(RandomData, ServerED25519KeyPair.PrivateKey);
                MyLoginModels.RequestStatus = "Successed: Kindly verify the signed challenge received from the server";
                MyLoginModels.ServerECDSAPKBase64String = Convert.ToBase64String(ServerED25519KeyPair.PublicKey);
                MyLoginModels.SignedRandomChallengeBase64String = Convert.ToBase64String(SignedRandomData);
            }
            else 
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Challenge` FROM `Support_Challenge` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                RandomData = Convert.FromBase64String(MySQLGeneralQuery.ExecuteScalar().ToString());
                SignedRandomData = SodiumPublicKeyAuth.Sign(RandomData, ServerED25519KeyPair.PrivateKey);
                MyLoginModels.RequestStatus = "Successed: Getting challenge previously generated for you..";
                MyLoginModels.ServerECDSAPKBase64String = Convert.ToBase64String(ServerED25519KeyPair.PublicKey);
                MyLoginModels.SignedRandomChallengeBase64String = Convert.ToBase64String(SignedRandomData);
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            ServerED25519KeyPair.Clear();
            return MyLoginModels;
        }
    }
}

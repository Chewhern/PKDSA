﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PKDSA_LoginWithSubKeysDemo.Model;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net;

namespace PKDSA_LoginWithSubKeysDemo.APIMethodHelper
{
    public static class ChallengeRequestor
    {
        public static LoginModels RequestChallengeFromServer(String User_ID, String Key_Identifier)
        {
            using (var client = new HttpClient())
            {
                //Because this is a demonstration application for web API consumption that uses a provider's service
                //The web API serving IP address must be hard coded..
                client.BaseAddress = new Uri("https://chronops.xyz:5001/api/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("ChallengeRequestor?User_ID=" + User_ID + "&Key_Identifier=" + Key_Identifier);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    return JsonConvert.DeserializeObject<LoginModels>(Result);
                }
                else
                {
                    return new LoginModels();
                }
            }
        }

        public static LoginModels GetLostChallengeFromServer(String User_ID, String Key_Identifier)
        {
            using (var client = new HttpClient())
            {
                //Because this is a demonstration application for web API consumption that uses a provider's service
                //The web API serving IP address must be hard coded..
                client.BaseAddress = new Uri("https://chronops.xyz:5001/api/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("ChallengeRequestor/GetLostChallenge?User_ID=" + User_ID + "&Key_Identifier=" + Key_Identifier);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    return JsonConvert.DeserializeObject<LoginModels>(Result);
                }
                else
                {
                    return new LoginModels();
                }
            }            
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PKDSA_LoginWithSubKeysDemo.APIMethodHelper;
using PKDSA_LoginWithSubKeysDemo.Model;
using ASodium;
using System.Net.Http.Headers;
using System;

namespace PKDSA_LoginWithSubKeysDemo.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            ViewData["Stage"] = "1st";
            HttpContext.Session.SetString("Stage", "1st");
        }

        public void OnPost() 
        {
            String Stage = HttpContext.Session.GetString("Stage");
            if (Stage.CompareTo("1st") == 0)
            {
                //Please do remember that this serves only as a guideline
                //The actual implementation may vary from language to language
                //and how a developer choose to implement
                String User_ID = Request.Form["User_ID"].ToString();
                String Sub_Key_Identifier = Request.Form["Sub_Key_Identifier"].ToString();
                String Base64Challenge = "";
                LoginModels myLoginModel = new LoginModels();
                Byte[] ServerPublicKey = new Byte[] { };
                Byte[] SignedChallengeFromServer = new Byte[] { };
                Byte[] ChallengeFromServer = new Byte[] { };

                if ((User_ID == null || Sub_Key_Identifier == null) == true && (User_ID.CompareTo("") == 0 || Sub_Key_Identifier.CompareTo("") == 0) == true)
                {
                    Console.WriteLine("User_ID and Sub_Key_Identifier must not be null or empty");
                }
                else 
                {
                    try
                    {
                        myLoginModel = ChallengeRequestor.RequestChallengeFromServer(User_ID, Sub_Key_Identifier);
                    }
                    catch 
                    {
                        myLoginModel = ChallengeRequestor.GetLostChallengeFromServer(User_ID, Sub_Key_Identifier);
                    }
                    if (myLoginModel.RequestStatus.Contains("Error") == true)
                    {
                        throw new Exception(myLoginModel.RequestStatus);
                    }
                    else 
                    {
                        ServerPublicKey = Convert.FromBase64String(myLoginModel.ServerECDSAPKBase64String);
                        SignedChallengeFromServer = Convert.FromBase64String(myLoginModel.SignedRandomChallengeBase64String);
                        ChallengeFromServer = SodiumPublicKeyAuth.Verify(SignedChallengeFromServer, ServerPublicKey);
                        Base64Challenge = Convert.ToBase64String(ChallengeFromServer);
                    }
                }
                HttpContext.Session.SetString("Stage", "2nd");
                HttpContext.Session.SetString("User_ID", User_ID);
                HttpContext.Session.SetString("Sub_Key_Identifier", Sub_Key_Identifier);
                HttpContext.Session.SetString("Base64Challenge", Base64Challenge);
                ViewData["Stage"] = "2nd";
                ViewData["Base64Challenge"]=Base64Challenge;
            }
            else 
            {
                String User_ID = HttpContext.Session.GetString("User_ID");
                String Sub_Key_Identifier = HttpContext.Session.GetString("Sub_Key_Identifier");
                String Base64Challenge = HttpContext.Session.GetString("Base64Challenge");
                String Signed_Challenge = Request.Form["Signed_Challenge"].ToString();
                String Status = "";

                if ((User_ID == null || Sub_Key_Identifier == null) == true && (User_ID.CompareTo("") == 0 || Sub_Key_Identifier.CompareTo("") == 0) == true)
                {
                    Console.WriteLine("User_ID and Sub_Key_Identifier must not be null or empty");
                }
                else
                {
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri("https://chronops.xyz:5001/api/");
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(
                            new MediaTypeWithQualityHeaderValue("application/json"));
                        var response = client.GetAsync("UserLogin?User_ID=" + User_ID + "&Key_Identifier=" + Sub_Key_Identifier + "&URLEncoded_Signed_Challenge=" + System.Web.HttpUtility.UrlEncode(Signed_Challenge));
                        response.Wait();
                        var result = response.Result;
                        if (result.IsSuccessStatusCode)
                        {
                            var readTask = result.Content.ReadAsStringAsync();
                            readTask.Wait();

                            var Result = readTask.Result;

                            Status = Result.Substring(1, Result.Length - 2);
                        }
                        else
                        {
                            Console.WriteLine("Something is wrong on server side");
                        }
                    }
                }
                HttpContext.Session.SetString("Stage", "3rd");
                ViewData["Stage"] = "3rd";
                ViewData["Base64Challenge"] = Base64Challenge;
                ViewData["Status"] = Status;
            }
        }
    }
}
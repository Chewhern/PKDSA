﻿using PKDSA_Admin_CApp.Helper;
using PKDSA_Admin_CApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Security.Cryptography.X509Certificates;

namespace PKDSA_Admin_CApp.APIMethodHelper
{
    public static class AdminChallengeRequestor
    {
        public static String RequestCStatus = "";

        public static LoginModels RequestChallengeFromServer(String User_ID)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("AdminChallengeRequestor?User_ID=" + User_ID);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    return JsonConvert.DeserializeObject<LoginModels>(Result);
                }
                else
                {
                    RequestCStatus = "There's something wrong on the server side..";
                    return new LoginModels();
                }
            }
        }

        public static LoginModels GetLostChallengeFromServer(String User_ID)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("AdminChallengeRequestor/GetLostChallenge?User_ID=" + User_ID);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    return JsonConvert.DeserializeObject<LoginModels>(Result);
                }
                else
                {
                    RequestCStatus = "There's something wrong on the server side..";
                    return new LoginModels();
                }
            }
        }
    }
}

﻿using Newtonsoft.Json;
using PKDSA_Admin_CApp.Helper;
using PKDSA_Admin_CApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace PKDSA_Admin_CApp.APIMethodHelper
{
    public static class ChangeOOBData
    {
        public static String ChangeSingleOOBData(String AS_ID,String Admin_ID, String Base64EncodedChallenge)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("AccountSupport/ChangeOOB?AS_ID="+AS_ID+"&Admin_ID=" + Admin_ID + "&URL_EncodedSignedChallenge=" + System.Web.HttpUtility.UrlEncode(Base64EncodedChallenge));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    return Result;
                }
                else
                {
                    return "There's something wrong on the server side..";
                }
            }
        }
    }
}

﻿using ASodium;
using BCASodium;
using MySql.Data.MySqlClient;
using PKDSA_Admin_CApp.APIMethodHelper;
using PKDSA_Admin_CApp.Helper;
using PKDSA_Admin_CApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PKDSA_Admin_CApp.MethodHelper
{
    public static class M_ChangeMasterPK
    {
        public static void ChangeMasterPKFunction() 
        {
            String User_ID = File.ReadAllText(StartUp.ManagementAppUserRootFolder + "User_ID.txt");
            LoginModels myLoginModels = AdminChallengeRequestor.RequestChallengeFromServer(User_ID);
            if (myLoginModels.RequestStatus.Contains("Error") == false)
            {
                Byte[] SignedChallenge = Convert.FromBase64String(myLoginModels.SignedRandomChallengeBase64String);
                Byte[] PublicKey = Convert.FromBase64String(myLoginModels.ServerECDSAPKBase64String);
                Byte[] Challenge = SodiumPublicKeyAuth.Verify(SignedChallenge, PublicKey);
                Byte[] PrivateKey = File.ReadAllBytes(StartUp.ManagementAppUserRootFolder + "PrivateKey.txt");
                Byte[] LocalSignedChallenge = new Byte[] { };
                if (PrivateKey.Length == 64)
                {
                    LocalSignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, PrivateKey);
                }
                else
                {
                    LocalSignedChallenge = SecureED448.GenerateSignatureMessage(PrivateKey, Challenge, new Byte[] { });
                }
                DataModels myDataModel = GetMasterPKData.GetChangeMPKDataList(User_ID, Convert.ToBase64String(LocalSignedChallenge));
                if (!(myDataModel.Data.Length == 1 && myDataModel.Data[0].Contains("Error") == true))
                {
                    String[] AS_IDs = new String[myDataModel.Data.Length / 3];
                    String[] User_IDs = new String[myDataModel.Data.Length / 3];
                    String[] SignedChallenges = new string[myDataModel.Data.Length / 3];
                    int Loop = 0;
                    int ArrayLoop = 0;
                    int FirstIteration = AS_IDs.Length;
                    int SecondIteration = AS_IDs.Length * 2;
                    int ThirdIteration = AS_IDs.Length * 3;
                    while (Loop < FirstIteration)
                    {
                        AS_IDs[Loop] = myDataModel.Data[Loop];
                        Loop += 1;
                    }
                    while (Loop < SecondIteration)
                    {
                        User_IDs[ArrayLoop] = myDataModel.Data[Loop];
                        ArrayLoop += 1;
                        Loop += 1;
                    }
                    ArrayLoop = 0;
                    while (Loop < ThirdIteration)
                    {
                        SignedChallenges[ArrayLoop] = myDataModel.Data[Loop];
                        Loop += 1;
                    }
                    MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                    String ExceptionString = "";
                    int Count = 0;
                    String Status = "";
                    MyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                    Loop = 0;
                    while (Loop < User_IDs.Length)
                    {
                        MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `user` WHERE `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_IDs[Loop];
                        MySQLGeneralQuery.Connection = MyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                        if (Count == 1)
                        {
                            String OOB_PK = "";
                            Byte[] OOB_PK_Bytes = new Byte[] { };
                            Byte[] UserSignedChallenge = new Byte[] { };
                            Byte[] UserChallenge = new Byte[] { };
                            Boolean AbleToVerify = true;
                            MySQLGeneralQuery = new MySqlCommand();
                            MySQLGeneralQuery.CommandText = "SELECT `OOB_PK` FROM `user` WHERE `User_ID`=@User_ID";
                            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_IDs[Loop];
                            MySQLGeneralQuery.Connection = MyOwnMySQLConnection.MyMySQLConnection;
                            MySQLGeneralQuery.Prepare();
                            OOB_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                            OOB_PK_Bytes = Convert.FromBase64String(OOB_PK);
                            UserSignedChallenge = Convert.FromBase64String(SignedChallenges[Loop]);
                            try
                            {
                                if (OOB_PK_Bytes.Length == 32)
                                {
                                    UserChallenge = SodiumPublicKeyAuth.Verify(UserSignedChallenge, OOB_PK_Bytes);
                                }
                                else
                                {
                                    UserChallenge = SecureED448.GetMessageFromSignatureMessage(OOB_PK_Bytes, UserSignedChallenge, new Byte[] { });
                                }
                            }
                            catch
                            {
                                AbleToVerify = false;
                            }
                            if (AbleToVerify)
                            {
                                myLoginModels = AdminChallengeRequestor.RequestChallengeFromServer(User_ID);
                                if (myLoginModels.RequestStatus.Contains("Error") == false)
                                {
                                    SignedChallenge = Convert.FromBase64String(myLoginModels.SignedRandomChallengeBase64String);
                                    PublicKey = Convert.FromBase64String(myLoginModels.ServerECDSAPKBase64String);
                                    Challenge = SodiumPublicKeyAuth.Verify(SignedChallenge, PublicKey);
                                    LocalSignedChallenge = new Byte[] { };
                                    if (PrivateKey.Length == 64)
                                    {
                                        LocalSignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, PrivateKey);
                                    }
                                    else
                                    {
                                        LocalSignedChallenge = SecureED448.GenerateSignatureMessage(PrivateKey, Challenge, new Byte[] { });
                                    }
                                }
                                Status = RemoveSupportChallenge.DeleteSupportChallenge(Convert.ToBase64String(UserChallenge), User_ID, Convert.ToBase64String(LocalSignedChallenge));

                                if (Status.Contains("Error") == false)
                                {
                                    Console.WriteLine(User_IDs[Loop] + "'s account support challenge have been removed");
                                }
                                else
                                {
                                    Console.WriteLine(User_IDs[Loop] + "'s account support challenge was failed to be removed");
                                }

                                myLoginModels = AdminChallengeRequestor.RequestChallengeFromServer(User_ID);
                                if (myLoginModels.RequestStatus.Contains("Error") == false)
                                {
                                    SignedChallenge = Convert.FromBase64String(myLoginModels.SignedRandomChallengeBase64String);
                                    PublicKey = Convert.FromBase64String(myLoginModels.ServerECDSAPKBase64String);
                                    Challenge = SodiumPublicKeyAuth.Verify(SignedChallenge, PublicKey);
                                    LocalSignedChallenge = new Byte[] { };
                                    if (PrivateKey.Length == 64)
                                    {
                                        LocalSignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, PrivateKey);
                                    }
                                    else
                                    {
                                        LocalSignedChallenge = SecureED448.GenerateSignatureMessage(PrivateKey, Challenge, new Byte[] { });
                                    }
                                }

                                Status = ChangeMasterPK.ChangeSingleMasterPK(AS_IDs[Loop], User_ID, Convert.ToBase64String(LocalSignedChallenge));

                                if (Status.Contains("Error") == false)
                                {
                                    Console.WriteLine(AS_IDs[Loop] + " support ticket has been fulfilled. Master public key had been changed");
                                }
                                else
                                {
                                    Console.WriteLine(AS_IDs[Loop] + " support ticket failed to be fulfilled. Master public key had not been changed");
                                }

                                Console.WriteLine("Master public key with the user ID of " + User_IDs[Loop] + " have been updated");
                            }
                            else
                            {
                                Console.WriteLine(User_IDs[Loop] + " 's challenge had been failed to verify with previous out of band public key");
                            }
                        }
                        else
                        {
                            Console.WriteLine(User_IDs[Loop] + " user does not exist");
                        }
                        MySQLGeneralQuery = new MySqlCommand();
                        Loop += 1;
                    }
                }
                SodiumSecureMemory.SecureClearBytes(PrivateKey);
            }
        }
    }
}

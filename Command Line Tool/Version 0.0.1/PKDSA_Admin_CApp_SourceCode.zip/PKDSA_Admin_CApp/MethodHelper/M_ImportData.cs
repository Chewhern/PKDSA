﻿using MySql.Data.MySqlClient;
using PKDSA_Admin_CApp.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PKDSA_Admin_CApp.MethodHelper
{
    public static class M_ImportData
    {
        public static void OOBImportData() 
        {
            if (File.Exists(StartUp.ImportDataRootFolder + "Data.csv") == true)
            {
                MySqlCommand MySQLGeneralQuery = new MySqlCommand();
                String ExceptionString = "";
                int Count = 0;
                String Status = "";
                MyOwnMySQLConnection.LoadConnection(ref ExceptionString);
                String[] FileContents = File.ReadAllLines(StartUp.ImportDataRootFolder + "Data.csv");
                String[] FileRowContents = new String[] { };
                int Loop = 0;
                while (Loop <= FileContents.Length-1)
                {
                    FileRowContents = FileContents[Loop].Split(",");
                    MySQLGeneralQuery.CommandText = "INSERT INTO `user`(`User_ID`, `OOB_PK`, `Change_Date`) VALUES (@User_ID,@OOB_PK,@Change_Date)";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = FileRowContents[0];
                    MySQLGeneralQuery.Parameters.Add("@OOB_PK", MySqlDbType.Text).Value = FileRowContents[1];
                    MySQLGeneralQuery.Parameters.Add("@Change_Date", MySqlDbType.DateTime).Value = DateTime.UtcNow.AddHours(8);
                    MySQLGeneralQuery.Connection = MyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    MySQLGeneralQuery = new MySqlCommand();
                    Loop += 1;
                }
                if(FileContents.Length-1 == -1) 
                {
                    Console.WriteLine("There's no data to be imported");
                }
                else 
                {
                    Console.WriteLine("OOB data has been imported");
                }
                File.Delete(StartUp.ImportDataRootFolder + "Data.csv");
            }
        }
    }
}

﻿// See https://aka.ms/new-console-template for more information

using PKDSA_Admin_CApp.MethodHelper;

StartUp.StartUpFunction();

Console.WriteLine();
Console.WriteLine();
Console.WriteLine("========");
Console.WriteLine("There're 4 options available");
Console.WriteLine("1. Import out of band data");
Console.WriteLine("2. Change out of band public key");
Console.WriteLine("3. Change master public key");
Console.WriteLine("4. Exit");
Console.WriteLine();
Console.WriteLine();
Console.Write("Input the option such as 1 or 2 or 3 or 4:");
String Choice = Console.ReadLine();
while (Choice.CompareTo("4") != 0) 
{
    if (Choice.CompareTo("1") == 0) 
    {
        M_ImportData.OOBImportData();
    }
    else if (Choice.CompareTo("2") == 0) 
    {
        M_ChangeOOBData.ChangeAllOOBData();
    }
    else if (Choice.CompareTo("3") == 0) 
    {
        M_ChangeMasterPK.ChangeMasterPKFunction();
    }
    Choice = Console.ReadLine();
}
Console.WriteLine();
Console.WriteLine("========");
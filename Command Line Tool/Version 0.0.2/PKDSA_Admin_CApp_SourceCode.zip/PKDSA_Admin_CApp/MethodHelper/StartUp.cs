﻿using PKDSA_Admin_CApp.APIMethodHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace PKDSA_Admin_CApp.MethodHelper
{
    public static class StartUp
    {
        public static String SigningAppRootFolder = "";
        public static String ManagementAppServerRootFolder = "";
        public static String ManagementAppUserRootFolder = "";
        public static String LocalDatabaseRootFolder = "";
        public static String ImportDataRootFolder = "";

        public static void StartUpFunction() 
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
            {
                SigningAppRootFolder = AppContext.BaseDirectory + "\\SAppDSKP\\";
                ManagementAppServerRootFolder = AppContext.BaseDirectory + "\\ServerIP\\";
                ManagementAppUserRootFolder = AppContext.BaseDirectory + "\\User\\";
                LocalDatabaseRootFolder = AppContext.BaseDirectory + "\\DB_Credentials\\";
                ImportDataRootFolder = AppContext.BaseDirectory + "\\DataToBeImported\\";
            }
            else
            {
                SigningAppRootFolder = AppContext.BaseDirectory + "/SAppDSKP/";
                ManagementAppServerRootFolder = AppContext.BaseDirectory + "/ServerIP/";
                ManagementAppUserRootFolder = AppContext.BaseDirectory + "/User/";
                LocalDatabaseRootFolder = AppContext.BaseDirectory + "/DB_Credentials/";
                ImportDataRootFolder = AppContext.BaseDirectory + "/DataToBeImported/";
            }
            if (Directory.Exists(SigningAppRootFolder) == false)
            {
                Directory.CreateDirectory(SigningAppRootFolder);
            }
            if (Directory.Exists(ManagementAppServerRootFolder) == false)
            {
                Directory.CreateDirectory(ManagementAppServerRootFolder);
            }
            if (Directory.Exists(ManagementAppUserRootFolder) == false)
            {
                Directory.CreateDirectory(ManagementAppUserRootFolder);
            }
            if (Directory.Exists(LocalDatabaseRootFolder) == false) 
            {
                Directory.CreateDirectory(LocalDatabaseRootFolder);
            }
            if (Directory.Exists(ImportDataRootFolder) == false)
            {
                Directory.CreateDirectory(ImportDataRootFolder);
            }
            if (Directory.Exists(ManagementAppServerRootFolder) == true)
            {
                if (File.Exists(ManagementAppServerRootFolder + "IP.txt") == true)
                {
                    EstablishConnection.CreateLinkWithServer();
                    Console.WriteLine(EstablishConnection.ConnectionStatus);
                }
            }
        }
    }
}

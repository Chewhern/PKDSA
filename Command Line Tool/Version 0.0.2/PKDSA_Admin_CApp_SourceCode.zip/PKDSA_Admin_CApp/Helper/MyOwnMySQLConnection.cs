﻿using MySql.Data.MySqlClient;

namespace PKDSA_Admin_CApp.Helper
{
    public static class MyOwnMySQLConnection
    {
        public static MySqlConnection MyMySQLConnection = new MySqlConnection();
        public static Boolean CheckConnection;
        //Local connection with XAMPP/LAMP^server
        private static String SecretPath = AppContext.BaseDirectory+"\\DB_Credentials\\Credentials.txt";
        private static String ConnectionString = "";

        private static void setConnection() {
            using (StreamReader SecretPathReader = new StreamReader(SecretPath))
            {
                while ((ConnectionString = SecretPathReader.ReadLine()) != null)
                {
                    MyMySQLConnection.ConnectionString = ConnectionString;
                }
            }
        }

        public static Boolean LoadConnection(ref String Exception) {
            setConnection();
            try
            {
                MyMySQLConnection.Open();
                CheckConnection = true;
            }
            catch (MySqlException exception){
                CheckConnection = false;
                Exception = exception.ToString();
            }
            return CheckConnection;
        }
    }
}

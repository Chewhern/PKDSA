﻿namespace PKDSA_Admin_CApp.Model
{
    public class DataModels
    {
        public String[] Data { get; set; }
    }
}
